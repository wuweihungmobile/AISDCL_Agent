# AISDLC-SDD v0.01 框架初始化配置文件
# AISDLC-SDD (Spec-First / System Design Document Driven) Framework Init

> **重要**: 使用任何 AISDLC-SDD workflow 前，必須先載入此配置！

## 版本說明

AISDLC-SDD v0.01 是基於 AISDLC v0.09 的 **SDD（規格先行/系統設計文件驅動）** 擴展框架。

### SDD 三大支柱

1. **Spec-First Gate（規格先行閘門）** — SCG-0 ~ SCG-6 自動化品質閘門
2. **Design-as-Doc（設計即文件）** — ADR、C4、RTM 強制文件化
3. **Contract-Driven（契約驅動）** — OpenAPI 3.1 規格凍結後才開始實作

### 核心特色

- 繼承 AISDLC v0.09 全部核心機制（Agent、Workflow、Scenario、按需載入）
- 新增 SDD 專屬模板（51 個：48 md + 3 yaml）、CI/CD 規格（9 個）、場景增強（10 個）
- 強制 SCG 閘門：每個開發階段都有規格合規檢查（SCG-0 ~ SCG-6）
- 支援全部 10 個場景：Greenfield、Brownfield、Refactoring、Documentation、DevOps、Integration、Migration、Performance、Security、Testing（每個場景均有 SDD Enhancement）

📖 **SDD 核心原則**: [SDD_Core_Principles.md](SDD_Core_Principles.md)
📖 **目錄結構規則**: [FILE_DIRECTORY_RULES.md](FILE_DIRECTORY_RULES.md)
📖 **SDD 快速指引**: [guides/system/sdd/SDD_GUIDE.md](guides/system/sdd/SDD_GUIDE.md)

---

## 核心參考指南

### SDD 專屬指南

| 指南 | 說明 | 使用時機 |
|------|------|---------|
| [SDD_Core_Principles.md](SDD_Core_Principles.md) | SDD 三大支柱與 SCG 閘門定義 | 所有 SDD 場景 |
| [SDD_SPEC_FIRST_GATE.md](workflow/sdd-spec-first-gate/SDD_SPEC_FIRST_GATE.md) | Spec-First Gate 工作流 | SCG 閘門執行 |

### 場景增強文件

| 場景 | SDD 增強 | 說明 |
|------|---------|------|
| Greenfield | [SDD_GREENFIELD_ENHANCEMENT.md](scenarios/greenfield/SDD_GREENFIELD_ENHANCEMENT.md) | 全新專案的 SDD 強化流程 |
| Brownfield | [SDD_BROWNFIELD_ENHANCEMENT.md](scenarios/brownfield/SDD_BROWNFIELD_ENHANCEMENT.md) | 逆向規格工程 + Gap Analysis |
| Refactoring | [SDD_REFACTORING_ENHANCEMENT.md](scenarios/refactoring/SDD_REFACTORING_ENHANCEMENT.md) | Business Invariants + Mutation Testing |
| Documentation | [SDD_DOCUMENTATION_ENHANCEMENT.md](scenarios/documentation/SDD_DOCUMENTATION_ENHANCEMENT.md) | Living Documentation + ADR 維護 |
| DevOps | [SDD_DEVOPS_ENHANCEMENT.md](scenarios/devops/SDD_DEVOPS_ENHANCEMENT.md) | IaC-as-Spec + Pipeline Spec 先行 |
| Migration | [SDD_MIGRATION_ENHANCEMENT.md](scenarios/migration/SDD_MIGRATION_ENHANCEMENT.md) | Migration Contract Map（MCM）先行 |
| Integration | [SDD_INTEGRATION_ENHANCEMENT.md](scenarios/integration/SDD_INTEGRATION_ENHANCEMENT.md) | Consumer-Driven Contract + OpenAPI First |
| Testing | [SDD_TESTING_ENHANCEMENT.md](scenarios/testing/SDD_TESTING_ENHANCEMENT.md) | Test Pyramid Spec + Quality Gate |
| Performance | [SDD_PERFORMANCE_ENHANCEMENT.md](scenarios/performance/SDD_PERFORMANCE_ENHANCEMENT.md) | SLO/SLA Spec + PBS 先行 |
| Security | [SDD_SECURITY_ENHANCEMENT.md](scenarios/security/SDD_SECURITY_ENHANCEMENT.md) | STRIDE Threat Model + SAD 前置 |

### CI/CD 規格

| 規格 | 說明 |
|------|------|
| [SDD_CICD_BASE_LAYER.md](cicd/SDD_CICD_BASE_LAYER.md) | SDD CI/CD 基礎層（DocLint + SpecTrace + OpenAPI Validate + RTM Check） |
| [SDD_GREENFIELD_CICD.md](cicd/SDD_GREENFIELD_CICD.md) | Greenfield 專屬 CI/CD |
| [SDD_BROWNFIELD_CICD.md](cicd/SDD_BROWNFIELD_CICD.md) | Brownfield 專屬 CI/CD |
| [SDD_REFACTORING_CICD.md](cicd/SDD_REFACTORING_CICD.md) | Refactoring 專屬 CI/CD |
| [SDD_MIGRATION_CICD.md](cicd/SDD_MIGRATION_CICD.md) | Migration 專屬 CI/CD（MCM Validate + Contract Test Auto-Gen） |
| [SDD_INTEGRATION_CICD.md](cicd/SDD_INTEGRATION_CICD.md) | Integration 專屬 CI/CD（Consumer Contract Validate + Chaos Contract） |
| [SDD_TESTING_CICD.md](cicd/SDD_TESTING_CICD.md) | Testing 專屬 CI/CD（TestSpec Validate + Quality Gate + RTM Coverage） |
| [SDD_PERFORMANCE_CICD.md](cicd/SDD_PERFORMANCE_CICD.md) | Performance 專屬 CI/CD（PBS Validate + SLO Gate） |
| [SDD_SECURITY_CICD.md](cicd/SDD_SECURITY_CICD.md) | Security 專屬 CI/CD（STRIDE Validate + Compliance Matrix Auto-Check） |

### 繼承自 AISDLC v0.09 的指南

- **[AISDLC_ID_Naming_Convention.md](guides/system/naming/AISDLC_ID_Naming_Convention.md)** — 統一 ID 命名規範
- **[Estimation_Standards.md](guides/system/planning/Estimation_Standards.md)** — 估算標準化指南
- **[Document_Quality_Checklist.md](guides/system/quality/Document_Quality_Checklist.md)** — 文檔品質檢查清單
- **[C4_Model_Guidelines.md](guides/system/architecture/C4_Model_Guidelines.md)** — C4 架構設計指南

---

## 按需載入機制

採用與 AISDLC v0.09 相同的**情境感知按需載入**方式，初始載入僅需 ~200 tokens。

### 自動載入流程

```yaml
step_1: 讀取 AISDLC_SDD_INIT.md（本檔案）
step_2: 識別專案情境類型（greenfield / brownfield / refactoring / documentation / devops / migration / integration / testing / performance / security）
step_3: 從「Agent 自動載入配置表」讀取對應情境的配置
step_4: 自動載入 Primary Agents（讀取 YAML 並套用規則）
step_5: 記錄 Supporting Agents 列表（按需載入）
step_6: 載入對應 Workflows + SDD Enhancement
step_7: 確認 .claude/skills/ 已部署
step_8: 顯示載入狀態確認
step_9: 開始執行 SOP（含 SDD 閘門）
```

---

## Agent 自動載入配置表

```yaml
auto_load_config:
  greenfield:
    primary_agents:
      - path: "agent/core/03.pm-po-agent-zh.yaml"
        role: "專案啟動、商業價值決策"
      - path: "agent/core/04.sa-analyst-zh.yaml"
        role: "需求分析、FRD 產出"
    supporting_agents:
      - path: "agent/core/02.ba-business-analyst-zh.yaml"
        load_at: "Stage 2 - 需求驗證"
      - path: "agent/core/05.sd-architect-zh.yaml"
        load_at: "Stage 3 - 技術架構設計 + ADR"
      - path: "agent/core/07.qa-tester-zh.yaml"
        load_at: "Stage 4 - 驗收標準 + RTM"
      - path: "agent/core/06.dev-developer-zh.yaml"
        load_at: "Stage 5 - 實施開發"
      - path: "agent/specialized/technical-writer-zh.yaml"
        load_at: "Living Documentation 維護"
    sdd_enhancement: "scenarios/greenfield/SDD_GREENFIELD_ENHANCEMENT.md"
    workflows:
      - "sdd-spec-first-gate"
      - "requirements-extraction"
      - "validation-documentation"
      - "user-story-design"
      - "api-specification"
      - "consistency-check"
      - "interaction-analysis"
      - "adr-generation"
    sop_path: "scenarios/greenfield/SOP.md"
    cicd_spec: "cicd/SDD_GREENFIELD_CICD.md"

  brownfield:
    primary_agents:
      - path: "agent/core/04.sa-analyst-zh.yaml"
        role: "逆向規格工程、As-Is SRD、Gap Analysis"
      - path: "agent/specialized/dev-senior-zh.yaml"
        role: "技術評審、代碼分析"
    supporting_agents:
      - path: "agent/specialized/code-analyzer-zh.yaml"
        load_at: "Stage 1 - 代碼分析 + Tech Debt 量化"
      - path: "agent/core/05.sd-architect-zh.yaml"
        load_at: "Stage 3 - As-Is C4 + ADR Archaeology + To-Be SRD"
      - path: "agent/core/07.qa-tester-zh.yaml"
        load_at: "Stage 5 - As-Is 測試規格提取 + RTM"
      - path: "agent/core/06.dev-developer-zh.yaml"
        load_at: "Stage 8 - 實施開發"
      - path: "agent/specialized/technical-writer-zh.yaml"
        load_at: "Living Documentation 維護"
    sdd_enhancement: "scenarios/brownfield/SDD_BROWNFIELD_ENHANCEMENT.md"
    workflows:
      - "sdd-spec-first-gate"
      - "requirements-extraction"
      - "change-management"
      - "api-specification"
      - "consistency-check"
      - "interaction-analysis"
      - "adr-generation"
    sop_path: "scenarios/brownfield/SOP.md"
    cicd_spec: "cicd/SDD_BROWNFIELD_CICD.md"

  refactoring:
    primary_agents:
      - path: "agent/core/05.sd-architect-zh.yaml"
        role: "Before/After 架構設計、重構 ADR"
      - path: "agent/specialized/code-analyzer-zh.yaml"
        role: "品質基準線、技術債量化"
    supporting_agents:
      - path: "agent/core/04.sa-analyst-zh.yaml"
        load_at: "Stage 0 - Business Invariants 提取"
      - path: "agent/specialized/dev-senior-zh.yaml"
        load_at: "Stage 2 - 漸進式重構策略"
      - path: "agent/core/07.qa-tester-zh.yaml"
        load_at: "Stage 3 - Invariant Test Contract + Mutation Testing"
      - path: "agent/core/06.dev-developer-zh.yaml"
        load_at: "Stage 4 - 重構實作"
      - path: "agent/specialized/technical-writer-zh.yaml"
        load_at: "Before/After 文件化"
    sdd_enhancement: "scenarios/refactoring/SDD_REFACTORING_ENHANCEMENT.md"
    workflows:
      - "sdd-spec-first-gate"
      - "refactoring-planning-flow"
      - "requirements-extraction"
      - "change-management"
      - "api-specification"
      - "consistency-check"
      - "adr-generation"
    sop_path: "scenarios/refactoring/SOP.md"
    cicd_spec: "cicd/SDD_REFACTORING_CICD.md"

  documentation:
    primary_agents:
      - path: "agent/specialized/technical-writer-zh.yaml"
      - path: "agent/core/04.sa-analyst-zh.yaml"
      - path: "agent/core/05.sd-architect-zh.yaml"
    sdd_enhancement: "scenarios/documentation/SDD_DOCUMENTATION_ENHANCEMENT.md"
    workflows:
      - "sdd-spec-first-gate"
      - "documentation-flow"
      - "adr-generation"
    sop_path: "scenarios/documentation/SOP.md"
    cicd_spec: "cicd/SDD_CICD_BASE_LAYER.md"

  devops:
    primary_agents:
      - path: "agent/specialized/devops-engineer-zh.yaml"
      - path: "agent/core/05.sd-architect-zh.yaml"
      - path: "agent/core/04.sa-analyst-zh.yaml"
    sdd_enhancement: "scenarios/devops/SDD_DEVOPS_ENHANCEMENT.md"
    workflows:
      - "sdd-spec-first-gate"
      - "devops-setup-flow"
      - "adr-generation"
    sop_path: "scenarios/devops/SOP.md"
    cicd_spec: "cicd/SDD_CICD_BASE_LAYER.md"

  migration:
    primary_agents:
      - path: "agent/core/05.sd-architect-zh.yaml"
      - path: "agent/specialized/devops-engineer-zh.yaml"
      - path: "agent/specialized/integration-specialist-zh.yaml"
    sdd_enhancement: "scenarios/migration/SDD_MIGRATION_ENHANCEMENT.md"
    workflows:
      - "sdd-spec-first-gate"
      - "migration-planning-flow"
      - "adr-generation"
    sop_path: "scenarios/migration/SOP.md"
    cicd_spec: "cicd/SDD_MIGRATION_CICD.md"

  integration:
    primary_agents:
      - path: "agent/specialized/integration-specialist-zh.yaml"
      - path: "agent/core/05.sd-architect-zh.yaml"
      - path: "agent/core/07.qa-tester-zh.yaml"
    sdd_enhancement: "scenarios/integration/SDD_INTEGRATION_ENHANCEMENT.md"
    workflows:
      - "sdd-spec-first-gate"
      - "integration-analysis-flow"
      - "api-specification"
      - "adr-generation"
    sop_path: "scenarios/integration/SOP.md"
    cicd_spec: "cicd/SDD_INTEGRATION_CICD.md"

  testing:
    primary_agents:
      - path: "agent/specialized/qa-lead-zh.yaml"
      - path: "agent/specialized/qa-automation-zh.yaml"
      - path: "agent/core/07.qa-tester-zh.yaml"
    sdd_enhancement: "scenarios/testing/SDD_TESTING_ENHANCEMENT.md"
    workflows:
      - "sdd-spec-first-gate"
      - "testing-strategy-flow"
      - "adr-generation"
    sop_path: "scenarios/testing/SOP.md"
    cicd_spec: "cicd/SDD_TESTING_CICD.md"

  performance:
    primary_agents:
      - path: "agent/specialized/performance-engineer-zh.yaml"
      - path: "agent/core/05.sd-architect-zh.yaml"
    sdd_enhancement: "scenarios/performance/SDD_PERFORMANCE_ENHANCEMENT.md"
    workflows:
      - "sdd-spec-first-gate"
      - "performance-optimization-flow"
      - "adr-generation"
    sop_path: "scenarios/performance/SOP.md"
    cicd_spec: "cicd/SDD_PERFORMANCE_CICD.md"

  security:
    primary_agents:
      - path: "agent/specialized/security-engineer-zh.yaml"
      - path: "agent/specialized/compliance-officer-zh.yaml"
      - path: "agent/core/05.sd-architect-zh.yaml"
    sdd_enhancement: "scenarios/security/SDD_SECURITY_ENHANCEMENT.md"
    workflows:
      - "sdd-spec-first-gate"
      - "security-assessment-flow"
      - "adr-generation"
    sop_path: "scenarios/security/SOP.md"
    cicd_spec: "cicd/SDD_SECURITY_CICD.md"
```

---

## SDD 模板索引

### docs_template/sdd/ 模板清單

| 分類 | 模板 | 用途 | 適用場景 |
|------|------|------|---------|
| **requirements** | INVARIANT-SPEC-TEMPLATE.md | Business Invariant 規格 | Refactoring |
| **architecture** | AS-IS-SRD-TEMPLATE.md | 現況系統規格（逆向） | Brownfield |
| **architecture** | TO-BE-SRD-TEMPLATE.md | 目標系統規格 | Brownfield |
| **architecture** | BEFORE-ARCH-TEMPLATE.md | 重構前架構快照 | Refactoring |
| **architecture** | AFTER-ARCH-TEMPLATE.md | 重構後目標架構 | Refactoring |
| **architecture** | SDD-COMPLIANCE-AUDIT-TEMPLATE.md | SDD 合規審計 | All |
| **adr** | ADR-TEMPLATE.md | 架構決策記錄 | All |
| **adr** | ADR-INDEX.md | ADR 索引 | All |
| **api** | API-COMPAT-TEMPLATE.md | API 向後相容性聲明 | Brownfield |
| **testing** | RTM-TEMPLATE.md | 需求追蹤矩陣 | All |
| **testing** | RTM-EXISTING-SYSTEM-TEMPLATE.md | 既有系統 RTM | Brownfield |
| **testing** | INVARIANT-TEST-CONTRACT-TEMPLATE.md | 不變量測試契約 | Refactoring |
| **planning** | GAP-ANALYSIS-TEMPLATE.md | As-Is vs To-Be 差距分析 | Brownfield |
| **planning** | REFACTOR-PLAN-TEMPLATE.md | 重構計畫 | Refactoring |
| **quality** | CODE-QUALITY-BASELINE-TEMPLATE.md | 程式碼品質基準線 | Refactoring |
| **quality** | TECH-DEBT-SPEC-TEMPLATE.md | 技術債規格 | Brownfield/Refactoring |
| **development** | LIVING-DOC-STRATEGY-TEMPLATE.md | 活文件策略 | All |
| **api** | CONSUMER-CONTRACT-TEMPLATE.yaml | Consumer-Driven Contract | Integration |
| **api** | PROVIDER-API-SPEC-TEMPLATE.yaml | Provider API 規格 | Integration |
| **architecture** | MIGRATION-CONTRACT-MAP-TEMPLATE.md | 遷移契約映射 | Migration |
| **architecture** | MIGRATION-ADR-TEMPLATE.md | 遷移架構決策 | Migration |
| **architecture** | TRUST-BOUNDARY-MAP-TEMPLATE.md | 信任邊界圖 | Security |
| **architecture** | SAD-TEMPLATE.md | 安全架構文件 | Security |
| **architecture** | INFRA-REQUIREMENTS-SPEC-TEMPLATE.md | 基礎設施需求規格 | DevOps |
| **adr** | AUTOMATION-FRAMEWORK-ADR-TEMPLATE.md | 自動化框架選型 ADR | Testing |
| **adr** | PERFORMANCE-OPTIMIZATION-ADR-TEMPLATE.md | 效能優化 ADR | Performance |
| **testing** | TEST-STRATEGY-SPEC-TEMPLATE.md | 測試策略規格 | Testing |
| **testing** | TEST-CONTRACT-SPEC-TEMPLATE.md | 測試契約規格 | Testing |
| **testing** | DEFECT-CLASSIFICATION-SPEC-TEMPLATE.md | 缺陷分類規格 | Testing |
| **testing** | LIVING-TEST-REPORT-TEMPLATE.md | 活動測試報告 | Testing |
| **testing** | PERFORMANCE-BASELINE-SPEC-TEMPLATE.md | 效能基準規格（PBS） | Performance |
| **testing** | BASELINE-PERFORMANCE-REPORT-TEMPLATE.md | 效能基準報告 | Performance |
| **testing** | ASSET-INVENTORY-TEMPLATE.md | 系統資產清單 | Security |
| **testing** | STRIDE-THREAT-MODEL-TEMPLATE.md | STRIDE 威脅模型 | Security |
| **testing** | COMPLIANCE-MATRIX-TEMPLATE.md | 合規對照矩陣 | Security |
| **testing** | SECURITY-TEST-SPEC-TEMPLATE.md | 安全測試規格 | Security |
| **deployment** | PIPELINE-SPEC-TEMPLATE.md | Pipeline 規格 | DevOps |
| **deployment** | MONITORING-ALERT-SPEC-TEMPLATE.md | 監控告警規格 | Performance/DevOps |
| **deployment** | SECURITY-MONITORING-SPEC-TEMPLATE.md | 安全監控規格 | Security |
| **deployment** | INCIDENT-RESPONSE-SPEC-TEMPLATE.md | 事件回應規格 | Security |
| **deployment** | CUTOVER-SPEC-TEMPLATE.md | 切換規格 | Migration |
| **deployment** | ROLLBACK-SPEC-TEMPLATE.md | 回滾規格 | Migration |
| **deployment** | CANARY-SPEC-TEMPLATE.md | 金絲雀部署規格 | Migration |

---

## 專案文件目錄結構

```
AISDLC_SDD_v0.01/
├── docs/                              # 專案文檔輸出目錄
│   ├── 01_requirements/               # 需求文檔 (PRD, FRD, Invariant Specs)
│   ├── 02_architecture/               # 架構設計 (SRD, C4, ADR)
│   │   ├── adr/                       # Architecture Decision Records
│   │   └── api/                       # API 規格與相容性聲明
│   ├── 03_testing/                    # 測試文檔 (RTM, Test Plans, Contracts)
│   │   └── contracts/                 # Invariant Test Contracts
│   ├── 04_planning/                   # 開發規劃 (Gap Analysis, Refactor Plan)
│   ├── 05_development/                # 開發文檔 (Living Doc Strategy)
│   ├── 06_quality/                    # 品質保證 (Code Quality, Tech Debt)
│   ├── 07_design/                     # 設計文檔 (UI/UX, Database)
│   └── 08_deployment/                 # 部署文檔 (CI/CD, Release Notes)
```

---

## SCG 閘門總覽

| Gate | 名稱 | 檢查內容 | 適用階段 |
|------|------|---------|---------|
| SCG-0 | Requirement Spec Gate | PRD/FRD 完整性、ID 追蹤 | 需求凍結前 |
| SCG-1 | Design Spec Gate | SRD + API Spec 完整性 | 設計凍結前 |
| SCG-2 | Architecture Review Gate | C4 圖 + ADR 完整性 | 架構凍結前 |
| SCG-3 | Contract Freeze Gate | OpenAPI 3.1 規格凍結 | 開發啟動前 |
| SCG-4 | Implementation Compliance Gate | 實作與規格一致性 | PR Review |
| SCG-5 | RTM Completeness Gate | 需求追蹤矩陣 100% | 交付前 |
| SCG-6 | Release Readiness Gate | 全閘門通過確認 | 發布前 |

---

**來源框架**: AISDLC v0.09
**建立日期**: 2026-04-12
**版本**: AISDLC-SDD v0.01
