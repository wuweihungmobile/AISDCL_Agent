# AISDLC-SDD v0.01 檔案目錄維護與分類規則
# File & Directory Maintenance Rules

**版本**: v0.04
**建立日期**: 2026-04-12
**來源框架**: AISDLC v0.09

---

## 目錄結構總覽

```
AISDLC_SDD_v0.01/
│
├── 📄 AISDLC_SDD_INIT.md                 # 框架初始化配置（入口文件）
├── 📄 FILE_DIRECTORY_RULES.md            # 本文件 — 目錄結構規則
├── 📄 README.md                          # 框架概述與快速入門
├── 📄 SDD_Core_Principles.md             # SDD 三大支柱核心原則
├── 📄 AISDLC_SDD_UPGRADE_SOP.md         # ★ 框架升版 SOP（Phase 07 新增）
├── 📄 AISDLC_SDD_UPGRADE_CHECKLIST.md   # ★ 升版前完整檢查清單（Phase 07 新增）
├── 📄 SDD_VERSION_HISTORY.md            # ★ 版本變更歷程記錄（Phase 07 新增）
│
├── 📁 agent/                         # Agent 配置
│   ├── 📁 core/                      # 7 核心 Agent（含 SDD 技能）
│   │   ├── 01.agent-template-zh.yaml
│   │   ├── 02.ba-business-analyst-zh.yaml
│   │   ├── 03.pm-po-agent-zh.yaml
│   │   ├── 04.sa-analyst-zh.yaml      # +sdd_brownfield, +sdd_refactoring
│   │   ├── 05.sd-architect-zh.yaml    # +sdd_brownfield, +sdd_refactoring
│   │   ├── 06.dev-developer-zh.yaml
│   │   └── 07.qa-tester-zh.yaml      # +sdd_phase03
│   ├── 📁 specialized/               # 專業化 Agent（含 SDD 增強）
│   │   ├── code-analyzer-zh.yaml     # +sdd_phase03
│   │   ├── dev-senior-zh.yaml        # +sdd_refactoring
│   │   ├── technical-writer-zh.yaml  # +sdd_documentation
│   │   ├── compliance-officer-zh.yaml
│   │   ├── devops-engineer-zh.yaml
│   │   ├── integration-specialist-zh.yaml
│   │   ├── performance-engineer-zh.yaml
│   │   ├── qa-automation-zh.yaml
│   │   ├── qa-lead-zh.yaml
│   │   ├── qa-mobile-tester-zh.yaml
│   │   ├── qa-web-tester-zh.yaml
│   │   ├── sd-mobile-architect-zh.yaml
│   │   ├── sd-web-architect-zh.yaml
│   │   └── security-engineer-zh.yaml
│   ├── AGENT_COLLABORATION_PATTERNS.md
│   ├── AGENT_PHASE2_UPDATE_GUIDE.md
│   └── README.md
│
├── 📁 scenarios/                     # 10 大情境（含 SDD 增強）+ 跨場景指南
│   ├── 📄 README.md                 # ★ 場景選擇入口（含 SCG 閘門說明）
│   ├── 📄 SCENARIO_AGENT_MAPPING.md # ★ 場景 × Agent 對應表（SDD 10 場景版）
│   ├── 📄 ERROR_RECOVERY_GUIDE.md   # 執行錯誤恢復指南
│   ├── 📄 FRONTEND_SPECIFIC_GUIDE.md # 前端特定指南
│   ├── 📄 SCALING_GUIDE.md          # 框架擴展指南
│   ├── 📄 SCENARIO_TRANSITION_GUIDE.md # 場景切換指南（含 SDD 轉換規則）
│   ├── 📁 greenfield/               # Greenfield（全新開發）
│   │   ├── SOP.md / SOP_DeepDive.md / SOP_QuickRef.md
│   │   ├── Parallel_Execution_Guide.md
│   │   ├── SDD_GREENFIELD_ENHANCEMENT.md   # ★ SDD 增強
│   │   └── 📁 checklists/
│   ├── 📁 brownfield/               # Brownfield（既有系統擴充）
│   │   ├── SOP.md / SOP_DeepDive.md / SOP_QuickRef.md
│   │   └── SDD_BROWNFIELD_ENHANCEMENT.md   # ★ SDD 增強
│   ├── 📁 refactoring/              # Refactoring（系統重構）
│   │   ├── SOP.md / SOP_DeepDive.md / SOP_QuickRef.md
│   │   └── SDD_REFACTORING_ENHANCEMENT.md  # ★ SDD 增強
│   ├── 📁 documentation/            # Documentation（文件維護）
│   │   ├── SOP.md / SOP_DeepDive.md / SOP_QuickRef.md
│   │   └── SDD_DOCUMENTATION_ENHANCEMENT.md # ★ SDD 增強
│   ├── 📁 devops/                   # DevOps / CI/CD
│   │   ├── SOP.md / SOP_DeepDive.md / SOP_QuickRef.md
│   │   └── SDD_DEVOPS_ENHANCEMENT.md       # ★ SDD 增強（IaC-as-Spec）
│   ├── 📁 migration/                # Migration（系統遷移）
│   │   ├── SOP.md / SOP_QuickRef.md
│   │   └── SDD_MIGRATION_ENHANCEMENT.md    # ★ SDD 增強（MCM 先行）
│   ├── 📁 integration/              # Integration（第三方整合）
│   │   ├── SOP.md / SOP_DeepDive.md / SOP_QuickRef.md
│   │   └── SDD_INTEGRATION_ENHANCEMENT.md  # ★ SDD 增強（CDC + OpenAPI First）
│   ├── 📁 testing/                  # Testing / QA
│   │   ├── SOP.md / SOP_DeepDive.md / SOP_QuickRef.md
│   │   └── SDD_TESTING_ENHANCEMENT.md      # ★ SDD 增強（Test Pyramid Spec）
│   ├── 📁 performance/              # Performance（效能調校）
│   │   ├── SOP.md / SOP_DeepDive.md / SOP_QuickRef.md
│   │   └── SDD_PERFORMANCE_ENHANCEMENT.md  # ★ SDD 增強（SLO/PBS 先行）
│   └── 📁 security/                 # Security（安全合規）
│       ├── SOP.md / SOP_DeepDive.md / SOP_QuickRef.md
│       └── SDD_SECURITY_ENHANCEMENT.md     # ★ SDD 增強（STRIDE + SAD 前置）
│
├── 📁 workflow/                      # 工作流定義
│   ├── 📁 sdd-spec-first-gate/      # ★ SDD 專屬工作流
│   │   └── SDD_SPEC_FIRST_GATE.md
│   ├── 📁 core/                     # 核心工作流（繼承 AISDLC）
│   │   ├── api-specification.md
│   │   ├── change-management.md
│   │   ├── consistency-check.md
│   │   ├── interaction-analysis.md
│   │   ├── requirements-extraction.md
│   │   ├── sprint-execution.md
│   │   ├── user-story-design.md
│   │   └── validation-documentation.md
│   ├── 📁 scenario-specific/        # 場景工作流（繼承 AISDLC）
│   │   ├── brownfield-analysis-flow.md
│   │   ├── code-analysis-flow.md
│   │   ├── devops-setup-flow.md
│   │   ├── documentation-flow.md
│   │   ├── documentation-reconstruction-flow.md
│   │   ├── greenfield-complete-flow.md
│   │   ├── integration-analysis-flow.md
│   │   ├── migration-planning-flow.md
│   │   ├── performance-optimization-flow.md
│   │   ├── refactoring-planning-flow.md
│   │   ├── security-assessment-flow.md
│   │   ├── tech-stack-selection-flow.md
│   │   └── testing-strategy-flow.md
│   ├── 📁 adr-generation/
│   │   └── ADR_GENERATION.md
│   └── README.md
│
├── 📁 docs_template/                # 文檔模板
│   ├── 📁 sdd/                      # ★ SDD 專屬模板（51 個：48 md + 3 yaml）
│   │   ├── 📁 requirements/
│   │   │   └── INVARIANT-SPEC-TEMPLATE.md
│   │   ├── 📁 architecture/
│   │   │   ├── AS-IS-SRD-TEMPLATE.md
│   │   │   ├── TO-BE-SRD-TEMPLATE.md
│   │   │   ├── BEFORE-ARCH-TEMPLATE.md
│   │   │   ├── AFTER-ARCH-TEMPLATE.md
│   │   │   └── SDD-COMPLIANCE-AUDIT-TEMPLATE.md
│   │   ├── 📁 adr/
│   │   │   ├── ADR-TEMPLATE.md
│   │   │   └── ADR-INDEX.md
│   │   ├── 📁 api/
│   │   │   └── API-COMPAT-TEMPLATE.md
│   │   ├── 📁 testing/
│   │   │   ├── RTM-TEMPLATE.md
│   │   │   ├── RTM-EXISTING-SYSTEM-TEMPLATE.md
│   │   │   └── INVARIANT-TEST-CONTRACT-TEMPLATE.md
│   │   ├── 📁 planning/
│   │   │   ├── GAP-ANALYSIS-TEMPLATE.md
│   │   │   └── REFACTOR-PLAN-TEMPLATE.md
│   │   ├── 📁 quality/
│   │   │   ├── CODE-QUALITY-BASELINE-TEMPLATE.md
│   │   │   └── TECH-DEBT-SPEC-TEMPLATE.md
│   │   └── 📁 development/
│   │       └── LIVING-DOC-STRATEGY-TEMPLATE.md
│   ├── 📁 core/                     # 核心模板（繼承 AISDLC）
│   │   ├── 📁 api/
│   │   ├── 📁 frd/
│   │   ├── 📁 prd/
│   │   ├── 📁 srd/
│   │   └── 📁 tests/
│   ├── 📁 scenario_specific/        # 場景模板（繼承 AISDLC）
│   │   ├── 📁 analysis/
│   │   ├── 📁 brownfield/
│   │   ├── 📁 devops/
│   │   ├── 📁 documentation/
│   │   ├── 📁 integration/
│   │   ├── 📁 migration/
│   │   ├── 📁 performance/
│   │   └── 📁 testing/
│   ├── 📁 support/                  # 支援模板（繼承 AISDLC）
│   └── README.md
│
├── 📁 cicd/                         # ★ SDD CI/CD 規格
│   ├── SDD_CICD_BASE_LAYER.md       # 基礎層（DocLint + SpecTrace + OpenAPI + RTM）
│   ├── SDD_GREENFIELD_CICD.md       # Greenfield CI/CD
│   ├── SDD_BROWNFIELD_CICD.md       # Brownfield CI/CD
│   ├── SDD_REFACTORING_CICD.md      # Refactoring CI/CD
│   ├── SDD_MIGRATION_CICD.md        # ★ Migration CI/CD（Phase 04）
│   ├── SDD_INTEGRATION_CICD.md      # ★ Integration CI/CD（Phase 04）
│   ├── SDD_TESTING_CICD.md          # ★ Testing CI/CD（Phase 05）
│   ├── SDD_PERFORMANCE_CICD.md      # ★ Performance CI/CD（Phase 05）
│   └── SDD_SECURITY_CICD.md         # ★ Security CI/CD（Phase 05）
│
├── 📁 guides/                       # 參考指南（繼承 AISDLC）
│   ├── 📁 system/                   # AI Agent 技術規格
│   │   ├── 📁 naming/
│   │   ├── 📁 architecture/
│   │   ├── 📁 api/
│   │   ├── 📁 testing/
│   │   ├── 📁 quality/
│   │   ├── 📁 planning/
│   │   └── 📁 agent/
│   ├── 📁 user/                     # 使用者指南
│   │   ├── 📁 onboarding/
│   │   ├── 📁 standards/
│   │   ├── 📁 technical/
│   │   └── 📁 process/
│   └── README.md
│
├── 📁 .claude/skills/               # Claude Code Skills（33 個）
│
├── 📁 prompts/                      # ★ 使用者指令集（P-01~03 Phase 07 新增）
│   ├── 📄 README.md
│   ├── 📁 quick-start/              # 快速啟動指引
│   │   ├── 5-minute-start.md        # 5 分鐘體驗 SDD Spec-First
│   │   ├── common-commands.md       # 常用指令速查（含 SCG 閘門）
│   │   ├── scenario-quick-reference.md # 10 場景快速啟動
│   │   └── troubleshooting-quick-guide.md # SDD 常見問題解決
│   ├── 📁 complete-flow/            # 完整流程範例
│   │   ├── end-to-end-greenfield-example.md
│   │   └── multi-scenario-combination-example.md
│   └── 📁 scenario-prompts/         # 10 個場景專用指令集
│       ├── README.md
│       ├── greenfield-prompts.md
│       ├── brownfield-prompts.md
│       ├── refactoring-prompts.md
│       ├── documentation-prompts.md
│       ├── testing-prompts.md
│       ├── devops-prompts.md
│       ├── integration-prompts.md
│       ├── migration-prompts.md
│       ├── performance-prompts.md
│       └── security-prompts.md
│
├── 📁 releases/                     # ★ 框架發布包管理（TL-01 Phase 07 新增）
│   ├── 📄 README.md
│   ├── 📁 backups/                  # 升版前備份
│   └── 📁 v0.01/                    # v0.01 發布包
│       └── RELEASE_NOTES_v0.01.md
│
├── 📁 tools/                        # 工具腳本
│   ├── init_project.sh
│   ├── init_project.ps1
│   ├── verify_traceability.sh
│   ├── AISDLC_CLAUDE_RULES.md
│   ├── PROJECT_CLAUDE_Template.md
│   └── README.md
│
├── 📁 build/                        # 建置產出（Layer 3 — 不複製）
│   ├── 📁 reports/
│   │   ├── 📁 analysis/
│   │   ├── 📁 phase/
│   │   ├── 📁 verification/
│   │   └── 📁 kpi/
│   ├── 📁 logs/
│   └── 📁 planning/
│       ├── 📁 active/               # 進行中的框架追蹤文件（當下為空，備未來使用）
│       └── 📁 archive/              # 已完成規劃文件歸檔（Phase 01-06、SDD_ADOPTION_TRACKER）
│
└── 📁 docs/                         # ★ 專案文檔輸出目錄（Layer 3 — 不複製，框架內為空目錄）
    ├── 📄 README.md                  # 目錄說明與子目錄用途對照表
    ├── 📁 01_requirements/           # PRD, FRD, Invariant Specs（.gitkeep）
    ├── 📁 02_architecture/           # SRD, C4, ADR, Trust Boundary Map
    │   ├── 📁 adr/                   # Architecture Decision Records（.gitkeep）
    │   ├── 📁 api/                   # API Contract Spec, Consumer Contract（.gitkeep）
    │   └── 📁 migration/             # Migration Contract Maps（.gitkeep）
    ├── 📁 03_testing/                # RTM, Test Plans, Test Specs
    │   └── 📁 contracts/             # Test Contract Spec, Invariant Test Contract（.gitkeep）
    ├── 📁 04_planning/               # Gap Analysis, Refactor Plans
    │   └── 📁 performance/           # Performance Baseline Specs（.gitkeep）
    ├── 📁 05_development/            # Living Doc Strategy（.gitkeep）
    ├── 📁 06_quality/                # Code Quality Baseline, Tech Debt Spec
    │   └── 📁 security/              # SAD, STRIDE, Compliance Matrix, Asset Inventory（.gitkeep）
    ├── 📁 07_design/                 # UI/UX, Database Design（.gitkeep）
    └── 📁 08_deployment/             # Pipeline Spec, Monitoring, Release Notes
        └── 📁 iac/                   # IaC Specifications（.gitkeep）
```

---

## 檔案分層規則

### Layer 1: 框架共享檔（根目錄）

| 檔案 | 說明 | 修改頻率 |
|------|------|---------|
| AISDLC_SDD_INIT.md | 框架初始化配置 | 升版時 |
| FILE_DIRECTORY_RULES.md | 目錄結構規則 | 結構變更時 |
| README.md | 框架概述 | 升版時 |
| SDD_Core_Principles.md | SDD 核心原則 | 極少 |

### Layer 2: 版本複製檔（框架核心）

升版時需要完整複製的目錄：

| 目錄 | 說明 | 檔案數 |
|------|------|--------|
| agent/ | Agent 配置 | 7 core + 14 specialized |
| scenarios/ | 場景 SOP + SDD 增強 | 10 場景 × (SOP + DeepDive + QuickRef + SDD Enhancement) |
| workflow/ | 工作流定義 | 1 SDD + 8 core + 13 scenario |
| docs_template/ | 文檔模板 | 51 SDD（48 md + 3 yaml）+ 50+ AISDLC |
| cicd/ | CI/CD 規格 | 9 個（Base Layer + 8 場景專屬） |
| guides/ | 參考指南 | 57+ |
| .claude/skills/ | Claude Code Skills | 39（33 繼承強化 + 6 SDD 新增） |
| tools/ | 工具腳本 | 6 個 |

### Layer 3: 專案產出檔（不複製）

| 目錄 | 說明 |
|------|------|
| docs/ | 專案文檔輸出（使用框架時產生，框架內為空目錄含 .gitkeep） |
| build/ | 框架建置報告、日誌、採用追蹤（active/）、歸檔（archive/） |

> **定位說明**：`docs/` 是**專案層**輸出，每個使用此框架的專案在此填入自己的 PRD/FRD/SRD/ADR 等文件。`build/` 是**框架層**的建置追蹤，不屬於任何一個具體專案。

---

## 寫檔規則

### SDD 模板寫入位置

| 模板類型 | 框架位置 | 專案產出位置 |
|---------|---------|------------|
| Invariant Spec | docs_template/sdd/requirements/ | docs/01_requirements/ |
| As-Is/To-Be SRD | docs_template/sdd/architecture/ | docs/02_architecture/ |
| Before/After Arch | docs_template/sdd/architecture/ | docs/02_architecture/ |
| ADR | docs_template/sdd/adr/ | docs/02_architecture/adr/ |
| API Compat | docs_template/sdd/api/ | docs/02_architecture/api/ |
| RTM | docs_template/sdd/testing/ | docs/03_testing/ |
| Invariant Test | docs_template/sdd/testing/ | docs/03_testing/contracts/ |
| Gap Analysis | docs_template/sdd/planning/ | docs/04_planning/ |
| Refactor Plan | docs_template/sdd/planning/ | docs/04_planning/ |
| Quality Baseline | docs_template/sdd/quality/ | docs/06_quality/ |
| Tech Debt Spec | docs_template/sdd/quality/ | docs/06_quality/ |
| Living Doc Strategy | docs_template/sdd/development/ | docs/05_development/ |
| Migration Contract Map | docs_template/sdd/architecture/ | docs/02_architecture/migration/ |
| API Consumer Contract | docs_template/sdd/api/ | docs/02_architecture/api/ |
| Performance Baseline Spec | docs_template/sdd/testing/ | docs/04_planning/performance/ |
| Security Architecture Doc | docs_template/sdd/architecture/ | docs/06_quality/security/ |
| STRIDE Threat Model | docs_template/sdd/testing/ | docs/06_quality/security/ |
| Asset Inventory | docs_template/sdd/testing/ | docs/06_quality/security/ |
| Compliance Matrix | docs_template/sdd/testing/ | docs/06_quality/security/ |
| Trust Boundary Map | docs_template/sdd/architecture/ | docs/02_architecture/ |
| Test Strategy Spec | docs_template/sdd/testing/ | docs/03_testing/ |
| Test Contract Spec | docs_template/sdd/testing/ | docs/03_testing/contracts/ |
| Defect Classification Spec | docs_template/sdd/testing/ | docs/03_testing/ |
| Security Test Spec | docs_template/sdd/testing/ | docs/03_testing/ |
| Monitoring Alert Spec | docs_template/sdd/deployment/ | docs/08_deployment/ |
| Security Monitoring Spec | docs_template/sdd/deployment/ | docs/08_deployment/ |
| Incident Response Spec | docs_template/sdd/deployment/ | docs/06_quality/security/ |
| Pipeline Spec | docs_template/sdd/deployment/ | docs/08_deployment/ |
| IaC Spec | docs_template/sdd/architecture/ | docs/08_deployment/iac/ |

### 報告寫入位置

| 報告類型 | 寫入位置 |
|---------|---------|
| 分析報告 | build/reports/analysis/ |
| 階段報告 | build/reports/phase/ |
| 驗證報告 | build/reports/verification/ |
| KPI 報告 | build/reports/kpi/ |
| 規劃文件 | build/planning/active/ |
| 歸檔文件 | build/planning/archive/ |
| 版本日誌 | build/logs/ |

---

## SDD 新增內容標記

以 ★ 標記的項目為 AISDLC-SDD 新增，非繼承自 AISDLC v0.09：

- ★ `SDD_Core_Principles.md` — SDD 核心原則
- ★ `cicd/` — 9 個 SDD CI/CD 規格（Phase 01-05 全 10 情境）
- ★ `docs_template/sdd/` — 51 個 SDD 專屬模板（48 md + 3 yaml，Phase 01-05 累計）
- ★ `workflow/sdd-spec-first-gate/` — Spec-First Gate 工作流
- ★ `scenarios/*/SDD_*_ENHANCEMENT.md` — 10 個場景 SDD 增強
- ★ `guides/system/sdd/SDD_GUIDE.md` — SDD 核心指引（Phase 06 新增）
- ★ Agent SDD 技能附加（21 個 Agent 全數完成 Phase 01-05 升級）
- ★ `docs/02_architecture/migration/` — Migration Contract Map 存放目錄
- ★ `docs/04_planning/performance/` — Performance Baseline Spec 存放目錄
- ★ `docs/06_quality/security/` — 安全相關文件存放目錄

---

**變更記錄**:

| 日期 | 版本 | 變更內容 |
|------|------|---------|
| 2026-04-12 | v0.01 | 初始建立，基於 AISDLC v0.09 + SDD Phase 01-03 轉換 |
| 2026-04-14 | v0.02 | Phase 04-06 完成：新增 CI/CD 規格（5個）、模板（30+）、docs 子目錄（migration/performance/security/iac）、SDD_GUIDE.md |
| 2026-04-14 | v0.03 | 目錄定位修正：SDD_ADOPTION_TRACKER 移至 build/planning/active/；docs/ 加入 README.md + .gitkeep；build/planning/active/ 子目錄說明；Layer 3 定位說明補充 |
| 2026-04-15 | v0.04 | Phase 07 補充：新增 scenarios/ 跨場景指南、prompts/、releases/、版本管理文件（UPGRADE_SOP/CHECKLIST/VERSION_HISTORY）、agent README.md、docs_template/prd/MVP |
