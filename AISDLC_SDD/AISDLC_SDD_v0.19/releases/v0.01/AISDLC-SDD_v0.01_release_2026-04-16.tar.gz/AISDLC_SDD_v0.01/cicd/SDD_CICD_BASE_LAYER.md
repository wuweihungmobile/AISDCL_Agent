# SDD CI/CD 基礎層規格
# SDD CI/CD Base Layer Specification

**版本**: v1.0
**建立日期**: 2026-04-12
**文件類型**: 部署規格（Deployment Specification）
**所屬分類**: docs/08_deployment/
**Spec Gate**: 🔷 SCG-2 Architecture Spec Gate

---

## 🎯 目的

定義 SDD 轉型中 CI/CD Pipeline 的基礎層（L0）擴充規格，加入文件導向的品質驗證步驟。

---

## 🏗️ L0 基礎層 SDD 擴充定義

### 現有 L0 基礎層（繼承自 AISDLC v0.09）

```
Build → Unit Test → Lint → Security Scan → Deploy
```

### SDD 擴充後 L0 基礎層

```
Build → Unit Test → Lint → DocLint → SpecTrace → Security Scan → Deploy
                              ↑           ↑
                    （新增 SDD 品質閘門）
```

---

## 📋 新增品質驗證步驟

### Step: DocLint（文件格式 Lint）

**目的**：驗證所有文件的格式符合 SDD 規範

**觸發條件**：每次 PR / Merge 時自動執行

**驗證內容**：
```yaml
doc_lint_rules:
  markdown:
    - "所有 .md 文件通過 markdownlint 規則"
    - "標題層級正確（H1 只有一個）"
    - "表格格式規範"
    - "程式碼區塊有指定語言"

  naming_convention:
    - "ADR 文件命名：ADR-{NNN}-{kebab-title}.md"
    - "CONTRACT 文件命名：CONTRACT-{module}-{version}.yaml"
    - "TCS 文件命名：TCS-{feature}-{date}.md"
    - "PBS 文件命名：PBS-{system}-{date}.md"
    - "SAD 文件命名：SAD-{system}-{date}.md"
    - "IaCS 文件命名：IaCS-{env}-{date}.md"

  directory_placement:
    - "ADR 文件必須在 docs/02_architecture/adr/"
    - "API Contract 必須在 docs/02_architecture/api/"
    - "測試契約必須在 docs/03_testing/contracts/"
    - "IaC 規格必須在 docs/08_deployment/iac/"

  link_check:
    - "所有內部 Markdown 連結可解析"
    - "相關文件引用存在"
```

**失敗處理**：DocLint 失敗時，Pipeline 中斷，必須修正後才能繼續。

---

### Step: SpecTrace（規格追溯驗證）

**目的**：驗證需求追溯鏈完整性（RTM 一致性）

**觸發條件**：每次 Stage 交付文件時執行

**驗證內容**：
```yaml
spec_trace_rules:
  traceability_chain:
    - "每個 Feature（F-XXX）必須有父 EPIC（EPIC-XXX）"
    - "每個 User Story（US-XXX）必須有父 Feature（F-XXX）"
    - "每個 AC（AC-XXX-Y）必須有父 US（US-XXX）"
    - "每個 AT（AT-XXX-Y-Z）必須有父 AC（AC-XXX-Y）"

  adr_coverage:
    - "每個架構決策點必須有對應 ADR 文件"
    - "ADR 文件狀態不可為空（Proposed/Accepted/Deprecated）"

  api_contract_coverage:
    - "每個 API 端點必須有對應 CONTRACT 文件"
    - "CONTRACT 文件 x-aisdlc.related_us 必須存在"

  rtm_freshness:
    - "RTM 最後更新日期不得超過 7 天（與需求變更同步）"
```

**失敗處理**：SpecTrace 失敗時，輸出缺失追溯項目清單，Pipeline 警告（不中斷，但需在下個 Sprint 修正）。

---

## 🔄 DocPipeline 標準化

**定義**：文件 CI/CD Pipeline 的標準化執行流程

```yaml
doc_pipeline:
  name: "AISDLC SDD DocPipeline"
  version: "v1.0"
  trigger:
    - "PR 到 main/develop 分支"
    - "文件目錄（docs/）有變更時"

  stages:
    - name: "Markdown Lint"
      tool: "markdownlint-cli2"
      config: ".markdownlint.yaml"
      fail_on_error: true

    - name: "Link Check"
      tool: "markdown-link-check"
      config: ".mlc_config.json"
      fail_on_error: false
      notes: "內部連結失敗為警告，外部連結失敗忽略（可能因網路限制）"

    - name: "ADR Index Update"
      tool: "adr-index-maintenance（technical-writer skill）"
      trigger: "docs/02_architecture/adr/ 有新增或修改時"
      output: "docs/02_architecture/adr/ADR-INDEX.md 自動更新"
      fail_on_error: false

    - name: "OpenAPI Validate"
      tool: "spectral / openapi-validator"
      config: ".spectral.yaml"
      trigger: "docs/02_architecture/api/ 有新增或修改時"
      validation_rules:
        - "OpenAPI 3.1 語法正確"
        - "所有 endpoint 有 summary"
        - "所有 Response Schema 已定義"
        - "x-aisdlc.related_us 欄位不為空"
        - "安全機制已定義（securitySchemes）"
      fail_on_error: true
      output: "build/reports/verification/APISpec-Validation-{date}.md"

    - name: "RTM Completeness Check"
      tool: "custom SpecTrace script"
      trigger: "docs/03_testing/RTM-*.md 有變更時"
      validation_rules:
        - "所有 US 都有對應 AC（無空白 AC 欄）"
        - "AC 覆蓋率 ≥ 80%（有 AT 的 AC 數 / 總 AC 數）"
        - "EPIC → Feature → US → AC 四層追溯完整"
        - "NFR 至少 1 個已對應到 US"
      fail_on_error: false
      output: "build/reports/verification/RTM-Completeness-{date}.md"
      notes: "覆蓋率低於 80% 為警告，低於 60% 為錯誤（中斷 Pipeline）"

    - name: "Spec Compliance Report"
      tool: "spec_compliance_check（Agent skill）"
      output: "build/reports/verification/SpecCompliance-{date}.md"
      fail_on_error: false
      notes: "生成報告供人工審查，不自動中斷 Pipeline"
```

---

## 📁 相關配置範本位置

```
docs/08_deployment/iac/
└── IaCS-cicd-base-layer.md  ← IaC 規格文件（此文件補充）

docs/08_deployment/
└── SDD_CICD_BASE_LAYER.md   ← 本文件
```

---

## 🔗 相關文件

- [SDD 核心原則](../02_architecture/SDD_Core_Principles.md)
- [Spec-First Gate Workflow](../../AISDLC_v0.09/workflow/sdd-spec-first-gate/SDD_SPEC_FIRST_GATE.md)
- [Phase 01 執行藍圖](../04_planning/AISDLC_TO_SDD_Planning_Phase_01.md)

---

**建立者**: AISDLC SDD 轉型架構師
**最後更新**: 2026-04-12
