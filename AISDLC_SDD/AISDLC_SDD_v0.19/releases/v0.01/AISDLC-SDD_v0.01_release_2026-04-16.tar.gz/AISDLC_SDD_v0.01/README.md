# AISDLC-SDD v0.01
# AI-assisted Software Development Lifecycle — Spec-First / System Design Document Driven

**版本**: v0.01
**建立日期**: 2026-04-12
**基於**: AISDLC v0.09（開發專注版）

---

## 什���是 AISDLC-SDD？

AISDLC-SDD 是基於 AISDLC 框架的 **SDD（規格先行 / 系統設計文件驅動）** 擴展，強調：

> **先有規格，後有程式碼。規格即文件，文件即契約。**

### SDD 三大支柱

| 支柱 | 說明 | 核心機制 |
|------|------|---------|
| **Spec-First Gate** | 規格先行閘門 | SCG-0 ~ SCG-6 自動化品質���門 |
| **Design-as-Doc** | 設計即文件 | ADR、C4 Model、RTM 強制文件化 |
| **Contract-Driven** | 契約驅動 | OpenAPI 3.1 規格凍結後才開始實作 |

### 繼承自 AISDLC v0.09

- 7 核心 Agent + 14 專業化 Agent
- 按需載入機制（初始 ~200 tokens）
- 情境驅動開發（Greenfield / Brownfield / Refactoring / Documentation）
- 完整工作流體系（8 核心 + 13 場景 + 1 SDD 專屬）
- 33 Claude Code Skills
- 文件驅動 + 人機協作確認點

---

## 快速開始（30 秒）

```
1. 載入框架: 讀取 AISDLC_SDD_INIT.md
2. 選擇場景: greenfield / brownfield / refactoring
3. 自動載入: Agent + Workflow + SDD Enhancement
4. 開始執行: SOP + SCG 閘門
```

---

## SDD 新增內容

### 18 個 SDD 專屬模板

| 分類 | 模板數 | 重點模板 |
|------|--------|---------|
| Architecture | 5 | As-Is SRD, To-Be SRD, Before/After Arch |
| ADR | 2 | ADR Template, ADR Index |
| Testing | 3 | RTM, Invariant Test Contract |
| Planning | 2 | Gap Analysis, Refactor Plan |
| Quality | 2 | Code Quality Baseline, Tech Debt Spec |
| Requirements | 1 | Invariant Spec |
| API | 1 | API Compat |
| Development | 1 | Living Doc Strategy |
| Compliance | 1 | SDD Compliance Audit |

### 4 個 CI/CD 規格

- **Base Layer**: DocLint + SpecTrace + OpenAPI Validate + RTM Check
- **Greenfield CICD**: 全新專案品質管線
- **Brownfield CICD**: 既有系統回歸管線
- **Refactoring CICD**: Invariant + Mutation 測試管線

### 6 個 Agent SDD 技能增強

| Agent | 新增技能 |
|-------|---------|
| sa-analyst | 逆向規格工程、Gap Analysis、Business Invariants 提取 |
| sd-architect | As-Is C4 生成、ADR Archaeology、Before/After 架構比較 |
| qa-tester | As-Is 測試規格提取、Invariant Test Contract |
| code-analyzer | Tech Debt 規格化、品質基準線 |
| dev-senior | 漸進式重構策略（Strangler Fig / Branch by Abstraction） |
| technical-writer | Living Documentation + ADR 維護 |

---

## 目錄結構

```
AISDLC_SDD_v0.01/
├── AISDLC_SDD_INIT.md          # 框架入口
├── FILE_DIRECTORY_RULES.md      # 目錄規則
├── README.md                    # 本文件
├── SDD_Core_Principles.md       # SDD 核心原則
├── agent/                       # 21 Agents（7 core + 14 specialized）
├── scenarios/                   # 4 場景（含 SDD 增強）
├── workflow/                    # 22 工作流（含 SDD Gate）
├── docs_template/               # 68+ 模板（含 18 SDD 專屬）
├── cicd/                        # 4 CI/CD 規格
├── guides/                      # 60+ 參考指南
├── .claude/skills/              # 33 Claude Code Skills
├── tools/                       # 工���腳本
├── build/                       # 建置產出
└── docs/                        # 專案文檔
```

詳見 [FILE_DIRECTORY_RULES.md](FILE_DIRECTORY_RULES.md)

---

## 相關文件

- [AISDLC_SDD_INIT.md](AISDLC_SDD_INIT.md) — 框架初始化（必讀）
- [SDD_Core_Principles.md](SDD_Core_Principles.md) — SDD 三大支柱
- [FILE_DIRECTORY_RULES.md](FILE_DIRECTORY_RULES.md) — 完整目錄結構規則
- [SDD Spec-First Gate](workflow/sdd-spec-first-gate/SDD_SPEC_FIRST_GATE.md) — SCG 工作流
