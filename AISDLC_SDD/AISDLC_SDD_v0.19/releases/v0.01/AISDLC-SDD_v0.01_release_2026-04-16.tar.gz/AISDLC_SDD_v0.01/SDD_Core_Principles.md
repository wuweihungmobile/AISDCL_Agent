# SDD 核心原則文件
# Specification/System Design Document Driven - Core Principles

**版本**: v1.0
**建立日期**: 2026-04-12
**文件類型**: 架構設計文件
**所屬分類**: docs/02_architecture/

---

## 🎯 SDD 轉型核心哲學

### 現狀 vs 目標對比

| 面向 | AISDLC v0.09 現狀 | SDD 目標狀態 |
|------|------------------|-------------|
| 文件定位 | 輔助說明（記錄決策） | 主要產出（驅動開發） |
| 規格時序 | 開發前後均可補齊 | 嚴格先於實作（Spec-First Gate） |
| 架構決策 | 隱性於 SRD 文字描述中 | ADR 顯性化，每決策一文件 |
| API 契約 | 建議產出，非強制 | 強制產出（Contract-First） |
| 品質閘門 | Human Checkpoint（🔴） | 🔴 Human + 🔷 Spec Compliance Gate |
| 圖表規範 | 選配（C4 Model 指引） | 強制：Context + Container 圖必產出 |
| 測試契約 | 測試計畫文件 | Test Contract Specification（先於開發） |

---

## 🏛️ SDD 三大核心支柱

```
┌─────────────────────────────────────────────────────────┐
│                SDD 三大核心支柱                           │
├─────────────────┬──────────────────┬────────────────────┤
│  Pillar 1       │  Pillar 2        │  Pillar 3          │
│  Spec-First     │  Design-as-Doc   │  Contract-Driven   │
│  Gate           │  (設計即文件)     │  Development       │
├─────────────────┼──────────────────┼────────────────────┤
│ 規格必須先於     │ 架構圖/決策/API   │ API & Interface    │
│ 所有實作行為    │ 是主要交付物      │ 契約先於實作        │
│                 │                  │                    │
│ 觸發點：        │ 觸發點：          │ 觸發點：            │
│ 每個 Stage 入口 │ 每個架構決策點    │ 任何整合介面定義    │
│                 │                  │                    │
│ 產出物：        │ 產出物：          │ 產出物：            │
│ Spec Freeze     │ ADR + C4 圖       │ OpenAPI / Contract │
│ Checklist       │ + 決策矩陣        │ Test Spec          │
└─────────────────┴──────────────────┴────────────────────┘
```

---

## 🔷 Spec-First Gate（SCG）機制

### 全局品質閘門定義

```
傳統 AISDLC Checkpoint：
  ...開發中... → 🔴 Human Checkpoint → ...繼續...

SDD 強化版 Checkpoint：
  ...規格撰寫中... → 🔷 Spec Compliance Gate → 🔴 Human Checkpoint → ...實作...
                         ↑
                    Agent 自動驗證
                    （spec_compliance_check）
```

### 六大閘門類型

| 閘門代號 | 名稱 | 觸發條件 | 負責 Agent |
|---------|------|---------|-----------|
| 🔷 SCG-1 | Requirement Spec Gate | FRD 完成前 | sa-analyst |
| 🔷 SCG-2 | Architecture Spec Gate | SRD 完成前 | sd-architect |
| 🔷 SCG-3 | API Contract Gate | API Spec 完成前 | integration-specialist / sd-architect |
| 🔷 SCG-4 | Test Strategy Gate | 測試計畫完成前 | qa-lead |
| 🔷 SCG-5 | Security Spec Gate | 安全設計完成前 | security-engineer |
| 🔷 SCG-6 | Performance Baseline Gate | 效能規格完成前 | performance-engineer |

---

## 🧩 共通 Agent Skill 定義

### Skill 1: `generate_adr` — Architecture Decision Record 生成

**適用情境**：所有 10 大情境，凡有架構或技術決策時觸發

**觸發規則**：
- 技術棧選擇（語言、框架、資料庫）
- 架構模式選擇（Monolith / Microservices / Event-Driven）
- 整合策略（API / Event / File / DB Share）
- 安全機制選擇（Auth / Encryption / Token）
- 部署策略（Container / Serverless / VM）

**ADR 存放位置**：`docs/02_architecture/adr/ADR-{NNN}-{title}.md`
**範本**：`docs/02_architecture/adr/ADR-TEMPLATE.md`

---

### Skill 2: `spec_compliance_check` — 規格符合性自我驗證

**用途**：Agent 在產出文件前，驗證輸出符合 SDD 規格要求

**驗證維度**：
- `completeness`：必填欄位、追溯鏈、ADR 建立
- `format`：命名規範、目錄位置、Markdown Lint
- `cross_reference`：上游引用、下游連結、ID 格式
- `sdd_specific`：規格先於實作、架構決策有 ADR、API 使用 OpenAPI

---

### Skill 3: `traceability_matrix` — 需求追溯矩陣生成

**用途**：建立從業務需求到測試案例的完整追溯鏈

**RTM 格式**：
```
| EPIC | Feature | User Story | AC | AT | API | NFR | Status |
```

**觸發時機**：Stage 3（FRD 後）、Stage 5（SRD 後）、Stage 6（測試計畫後）、任何需求變更後

---

## 📁 SDD 新增文件類型規範

| 文件類型 | 簡稱 | 存放位置 | 範本命名 |
|---------|------|---------|---------|
| Architecture Decision Record | ADR | `docs/02_architecture/adr/` | `ADR-{NNN}-{title}.md` |
| API Contract Spec | Contract | `docs/02_architecture/api/` | `CONTRACT-{module}-{version}.yaml` |
| Performance Baseline Spec | PBS | `docs/04_planning/performance/` | `PBS-{system}-{date}.md` |
| Security Architecture Doc | SAD | `docs/06_quality/security/` | `SAD-{system}-{date}.md` |
| Test Contract Spec | TCS | `docs/03_testing/contracts/` | `TCS-{feature}-{date}.md` |
| IaC Specification | IaCS | `docs/08_deployment/iac/` | `IaCS-{env}-{date}.md` |
| Migration Contract Map | MCM | `docs/02_architecture/migration/` | `MCM-{system}-{date}.md` |

---

## 🔗 相關文件

- [ADR 範本](docs_template/sdd/adr/ADR-TEMPLATE.md)
- [API Contract 範本](docs_template/sdd/api/CONTRACT-TEMPLATE.yaml)
- [RTM 範本](docs_template/sdd/testing/RTM-TEMPLATE.md)
- [SDD 快速指引](guides/system/sdd/SDD_GUIDE.md)
- [Phase 01 執行藍圖](../docs/04_planning/AISDLC_TO_SDD_Planning_Phase_01.md)

---

**建立者**: AISDLC SDD 轉型架構師
**最後更新**: 2026-04-12
