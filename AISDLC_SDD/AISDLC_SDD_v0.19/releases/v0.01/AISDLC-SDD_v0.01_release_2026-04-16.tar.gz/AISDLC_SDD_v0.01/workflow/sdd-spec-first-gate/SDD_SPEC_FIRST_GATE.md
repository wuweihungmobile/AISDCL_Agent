# SDD Spec-First Gate Workflow
# 規格優先閘門工作流程

**版本**: v1.0
**建立日期**: 2026-04-12
**工作流程類型**: 品質閘門（Quality Gate）
**分類**: SDD Phase 01 新增

---

## 🎯 工作流程目的

強制執行 SDD（Spec-First）原則：規格必須先於所有實作行為完成並通過驗證。

---

## 🔷 SCG 閘門類型與觸發條件

| 閘門 | 名稱 | 觸發條件 | 主責 Agent |
|-----|------|---------|-----------|
| 🔷 SCG-1 | Requirement Spec Gate | FRD 完成前 | sa-analyst |
| 🔷 SCG-2 | Architecture Spec Gate | SRD 完成前 | sd-architect |
| 🔷 SCG-3 | API Contract Gate | API Spec 完成前 | sd-architect / integration-specialist |
| 🔷 SCG-4 | Test Strategy Gate | 測試計畫完成前 | qa-lead |
| 🔷 SCG-5 | Security Spec Gate | 安全設計完成前 | security-engineer |
| 🔷 SCG-6 | Performance Baseline Gate | 效能規格完成前 | performance-engineer |

---

## 🔄 工作流程步驟

```
[任何 Stage 文件產出前]
         │
         ▼
1. Agent 識別文件類型 → 選擇對應 SCG 閘門
         │
         ▼
2. 執行 spec_compliance_check（Agent 自動驗證）
   ├── completeness 檢查
   ├── format 檢查
   ├── cross_reference 檢查
   └── sdd_specific 檢查
         │
         ├── 檢查失敗 ──→ 🔴 STOP：修正規格缺失後重新執行
         │
         ▼
3. 🔷 Spec Compliance Gate PASSED
         │
         ▼
4. 🔴 Human Checkpoint（人類審查）
         │
         ├── 需修改 ──→ 回到步驟 1
         │
         ▼
5. 文件產出 / 進入下一 Stage
```

---

## ✅ 閘門通過標準

### SCG-1（Requirement Spec Gate）
- [ ] FRD 所有欄位完整
- [ ] 每個 User Story 有可測試 AC
- [ ] 追溯鏈：EPIC → F → US → AC 完整
- [ ] 使用標準 ID 格式（EPIC/F/US/AC）

### SCG-2（Architecture Spec Gate）
- [ ] SRD 完整定義系統架構
- [ ] C4 Context + Container 圖已產出
- [ ] 所有架構決策有對應 ADR
- [ ] NFR 規格化（效能/安全/可用性目標）

### SCG-3（API Contract Gate）
- [ ] 使用 OpenAPI 3.1 格式
- [ ] 所有端點已定義 Request/Response Schema
- [ ] 安全機制已定義
- [ ] 追溯至 US/AC（x-aisdlc 欄位）

### SCG-4（Test Strategy Gate）
- [ ] 測試策略文件已完成
- [ ] 測試契約已定義（Test Contract Spec）
- [ ] RTM 已建立（追溯矩陣）
- [ ] 測試退出標準已定義

### SCG-5（Security Spec Gate）
- [ ] STRIDE 威脅模型已完成
- [ ] 安全架構文件（SAD）已完成
- [ ] 安全需求已納入 NFR

### SCG-6（Performance Baseline Gate）
- [ ] SLO/SLA 已定義（PBS 文件）
- [ ] 基準效能指標已建立
- [ ] 效能測試策略已定義

---

## 📂 相關文件

- [SDD 核心原則](../../docs/02_architecture/SDD_Core_Principles.md)
- [ADR 範本](../../docs/02_architecture/adr/ADR-TEMPLATE.md)
- [RTM 範本](../../docs/03_testing/RTM-TEMPLATE.md)
- [API Contract 範本](../../docs/02_architecture/api/CONTRACT-TEMPLATE.yaml)
